const express = require('express');
const bodyParser = require('body-parser');
const app = express();

// Middleware to parse JSON requests
app.use(bodyParser.json());

// POST route to handle the form submission
app.post('/submit-form', (req, res) => {
    const formData = req.body;
    console.log('Received form data:', formData);

    // You can add your data processing logic here (e.g., saving data to a database)
    
    // Send a response back to the frontend
    res.json({
        message: 'Form submitted successfully!',
        data: formData
    });
});

// Start the server
const port = 3000;
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
